Clone the project into your local mmachine.

Once you have a clone, open your terminal and

cd into project root directory.

Run npm install to install node_modules

The project is using Tailwindcss. Even though we haven't worked on the frontend yet

Subsequent pushes will come with some front-end styling.
