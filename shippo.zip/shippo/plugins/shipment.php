

<?php


require_once(__DIR__ . '../../vendor/autoload.php');
Shippo::setApiKey('shippo_test_57215259fd606e35b68e95626a44def23faa4b59');

/**
 * 
 * Details of address Object.
 */


$from_address = array(
    'name' => $s_name,
    'company' => $s_company,
    'street1' => $s_street,
    'city' => $s_city,
    'state' => $s_state,
    'zip' => $s_zip,
    'country' => $s_coutry,
    'phone' => $s_phone,
    'email' => $s_email,
);


/**
 * 
 * Destination of Shipment
 */
$to_address = array(
    'name' => $r_name,
    'company' => $r_company,
    'street1' => $r_street,
    'city' => $r_city,
    'zip' => $r_zip,
    'country' => $r_country,
    'phone' => $r_phone,
    'email' => $r_email,
    'metadata' => $r_metadata,
);



/**
 * 
 * Parcels Parcels gives details of the parcels
 */

$parcel = array(
    'length' => $p_length,
    'width' => $p_width,
    'height' => $p_height,
    'distance_unit' => $p_distace,
    'weight' => $p_weight,
    'mass_unit' => $p_lb,
);



/**
 * 
 * This Object creates is used to create shipment
 */

$create_shipment = Shippo_Shipment::create(
    array(
        'address_from' => $from_address,
        'address_to' => $to_address,
        'parcels' => array($parcel),
        'async' => false,
    )
);


/**
 * 
 * @array rates pulls in the rates of shipment
 */
$rate = $shipment['rates'][0];


/**
 * 
 * By Default transactions are set to true. 
 *
 */

$transaction = Shippo_Transaction::create(array(
    'rate' => $rate['object_id'],
    'async' => false,
));



// Print the shipping label from label_url
// Get the tracking number from tracking_number
if ($transaction['status'] == 'SUCCESS') {
    echo "--> " . "Shipping label url: " . $transaction['label_url'] . "\n";
    echo "--> " . "Shipping tracking number: " . $transaction['tracking_number'] . "\n";
} else {
    echo "Transaction failed with messages:" . "\n";
    foreach ($transaction['messages'] as $message) {
        echo "--> " . $message . "\n";
    }
}



//USE var_dump to view objects in the browser
// var_dump($to_address);
