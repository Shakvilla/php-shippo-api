<?php


require_once(__DIR__ . '../../vendor/autoload.php');



Shippo::setApiKey('shippo_test_57215259fd606e35b68e95626a44def23faa4b59');
