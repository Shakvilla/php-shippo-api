<?php



require_once(__DIR__ . '../../vendor/autoload.php');
Shippo::setApiKey('shippo_test_57215259fd606e35b68e95626a44def23faa4b59');



$status_params = array(
    'id' => $status_id,
    'carrier' => $carrier
);

//Get the tracking status of a shipment using Shippo_Track::get_status
//The response is stored in $status
//The complete reference for the returned Tracking object is available here: https://goshippo.com/docs/reference#tracks
$status = Shippo_Track::get_status($status_params);

//Example data for Track::create
//The complete reference for the tracks-create endpoint is available here: https://goshippo.com/docs/reference#tracks-create

$create_params = array(
    'carrier' => $carrier,
    'tracking_number' => $tracking_number,
    'metadata' => $metadata
);

//The response is stored in $webhook response and is identical to the response of Track::get_status 
$webhook_response = Shippo_Track::create($create_params);


echo "--> " . "Carrier: " . $webhook_response['carrier'] . "\n";
echo "--> " . "Shipping tracking number: " . $webhook_response['tracking_number'] . "\n";
echo "--> " . "Address from: " . $webhook_response['address_from'] . "\n";
echo "--> " . "Address to: " . $webhook_response['address_to'] . "\n";
echo "--> " . "Tracking Status: " . $webhook_response['tracking_status'] . "\n";
