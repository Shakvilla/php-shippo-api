<?php

include_once('init.php');


//Example data to create a batch shipment
//The complete reference to batch shipment creation is available here: https://goshippo.com/docs/reference#batches-create
$carrier = '<YOUR CARRIER ACCOUNT PRIVATE KEY>';





$data = array(
    'default_carrier_account' => $carrier,
    'default_servicelevel_token' => 'usps_priority',
    'label_filetype' => 'PDF_4x6',
    'metadata' => '',
    'batch_shipments' => array(
        array(
            'shipment' => array(
                'address_from' => array(
                    'name' => 'Mr Hippo',
                    'street1' => '965 Mission St',
                    'street2' => 'Ste 201',
                    'city' => 'San Francisco',
                    'state' => 'CA',
                    'zip' => '94103',
                    'country' => 'US',
                    'phone' => '4151234567',
                    'email' => 'mrhippo@goshippo.com'
                ),
                'address_to' => array(
                    'name' => 'Mrs Hippo',
                    'company' => '',
                    'street1' => 'Broadway 1',
                    'street2' => '',
                    'city' => 'New York',
                    'state' => 'NY',
                    'zip' => '10007',
                    'country' => 'US',
                    'phone' => '4151234567',
                    'email' => 'mrshippo@goshippo.com'
                ),
                'parcels' => array(
                    array(
                        'length' => '5',
                        'width' => '5',
                        'height' => '5',
                        'distance_unit' => 'in',
                        'weight' => '2',
                        'mass_unit' => 'oz'
                    )
                )
            )
        )
    )
);




//Example of batch shipment creation
$batch = Shippo_Batch::create($data);
echo "--> " . "Batch created with id: " . $batch['object_id'] . "\n";
