
<?php


require_once(__DIR__ . '../../vendor/autoload.php');
Shippo::setApiKey('shippo_test_57215259fd606e35b68e95626a44def23faa4b59');



// Example from_address array
// The complete refence for the address object is available here: https://goshippo.com/docs/reference#addresses
$from_address = array(
    'name' => $s_name,
    'company' => $s_company,
    'street1' => $s_street,
    'city' => $s_city,
    'state' => $s_state,
    'zip' => $s_zip,
    'country' => $s_coutry,
    'phone' => $s_phone,
    'email' => $s_email,
);

// Example to_address array
// The complete refence for the address object is available here: https://goshippo.com/docs/reference#addresses
$to_address = array(
    'name' => $r_name,
    'company' => $r_company,
    'street1' => $r_street,
    'city' => $r_city,
    'zip' => $r_zip,
    'country' => $r_country,
    'phone' => $r_phone,
    'email' => $r_email,
    'metadata' => $r_metadata,
);

// Parcel information array
// The complete reference for parcel object is here: https://goshippo.com/docs/reference#parcels
$parcel = array(
    'length' => $p_length,
    'width' => $p_width,
    'height' => $p_height,
    'distance_unit' => $p_distace,
    'weight' => $p_weight,
    'mass_unit' => $p_lb,
);

// Example CustomsItems object.
// The complete reference for customs object is here: https://goshippo.com/docs/reference#customsitems
$customs_item = array(
    'description' => $c_desc,
    'quantity' => $c_quanity,
    'net_weight' => $c_netweight,
    'mass_unit' => $c_mass,
    'value_amount' => $c_amount,
    'value_currency' => $c_currency,
    'origin_country' => $c_country,
    'tariff_number' => $c_tarrif_number,
);


// Creating the Customs Declaration
// The details on creating the CustomsDeclaration is here: https://goshippo.com/docs/reference#customsdeclarations
$customs_declaration = Shippo_CustomsDeclaration::create(
    array(
        'contents_type' => $content_type,
        'contents_explanation' => $contents_explanation,
        'non_delivery_option' => $none_delivery_option,
        'certify' => $certify,
        'certify_signer' => $certify_signer,
        'items' => array($customs_item),
    )
);


// Example shipment object
// For complete reference to the shipment object: https://goshippo.com/docs/reference#shipments
// This object has async=false, indicating that the function will wait until all rates are generated before it returns.
// By default, Shippo handles responses asynchronously. However this will be depreciated soon. Learn more: https://goshippo.com/docs/async
$create_shipment = Shippo_Shipment::create(
    array(
        'address_from' => $from_address,
        'address_to' => $to_address,
        'parcels' => array($parcel),
        'customs_declaration' => $customs_declaration->object_id,
        'async' => false,
    )
);

// Rates are stored in the `rates` array
// The details on the returned object are here: https://goshippo.com/docs/reference#rates
// Get the first rate in the rates results for demo purposes.
$rate = $shipment['rates'][0];

// Purchase the desired rate with a transaction request
// Set async=false, indicating that the function will wait until the carrier returns a shipping label before it returns
$transaction = Shippo_Transaction::create(array(
    'rate' => $rate['object_id'],
    'async' => false,
));

// Print the shipping label from label_url
// Get the tracking number from tracking_number
// Most international shipments require you to add 3 commercial invoices in the package's "pouch", a special envelope attached on the package. Shippo automatically creates these 3 copies for you, which will be returned in the Transaction's commercial_invoice field.
if ($transaction['status'] == 'SUCCESS') {
    echo "--> " . "Shipping label url: " . $transaction['label_url'] . "\n";
    echo "--> " . "Shipping tracking number: " . $transaction['tracking_number'] . "\n";
} else {
    echo "Transaction failed with messages:" . "\n";
    foreach ($transaction['messages'] as $message) {
        echo "--> " . $message . "\n";
    }
}
// For more tutorals of address validation, tracking, returns, refunds, and other functionality, check out our
// complete documentation: https://goshippo.com/docs/
?>